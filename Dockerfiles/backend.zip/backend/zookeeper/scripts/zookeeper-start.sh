#!/bin/bash

nohup {zookeeper_home}/bin/zkServer.sh start > /dev/null 2>&1 &

