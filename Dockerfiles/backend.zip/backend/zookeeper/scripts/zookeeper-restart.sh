#!/bin/bash

zookeeperstop

zookeeperstart
